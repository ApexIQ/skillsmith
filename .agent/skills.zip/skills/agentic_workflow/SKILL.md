---
version: 1.1.0
name: agentic_workflow
description: Use this skill when building agentic systems. Covers the agentic loop, tool usage, and iterative task execution patterns with 2024-2025 refinements.
tags: [agentic, workflow, patterns, reliability]
---

# 🔄 Agentic Workflow

> **Philosophy:** Agents gather context, take action, verify, and iterate until the goal is achieved. In 2025, the focus has shifted from "black box" agents to clear, composable workflows.

## The Agentic Loop (Search-then-GSD)

```
┌─────────────────────────────────────────────┐
│                                             │
│  1. SEARCH & READ (Skill Discovery)         │
│     └─ Search .agent/skills/ for context.   │
│                                             │
│  2. GSD LOOP (Agentic Execution)            │
│     ├─ DISCUSS: Clarify intent & context    │
│     ├─ PLAN: Create implementation plan     │
│     ├─ EXECUTE: Write code & run tools      │
│     └─ VERIFY: Test & validate results      │
│                                             │
│  3. ITERATE OR COMPLETE                     │
│     └─ If not done, update STATE.md         │
│                                             │
└─────────────────────────────────────────────┘
```

## Core Principles

### 1. Workflows > Agents
Prefer fixed code paths for subtasks. Only use dynamic agents for high-complexity, unpredictable goals.
- See: `anthropic_workflow_patterns` for detailed implementations.

### 2. Clear Tool Contracts (MCP)
Use the **Model Context Protocol** for consistent tool usage across all platforms.
- See: `mcp_integration_best_practices`.

### 3. Verification Before Completion
Never assume success. Always verify:

| Action | Verification |
|--------|--------------|
| File edit | Re-read file, check syntax |
| Code change | Run tests, check build |
| API call | Check response status |
| Command exec | Check exit code, read output |

## Advanced Patterns

For specialized reasoning and orchestration, combine this skill with:
- **`anthropic_workflow_patterns`**: Orchestrator-Worker, Evaluator-Optimizer.
- **`openai_agent_patterns`**: Critic Loops, Plan-and-Act.
- **`agentic_context_engineering`**: "Just-in-time" memory management.

## State Management (GSD Protocol)

Maintain agent state in `.agent/` using these files:
- **`PROJECT.md`**: Tech stack, vision, rules.
- **`ROADMAP.md`**: Long-term goals.
- **`STATE.md`**: Current task status and next atomic steps.

## Anti-Patterns

| ❌ Don't | ✅ Do |
|---------|------|
| Skip verification | Always verify actions |
| One agent does everything | Delegate to specialized patterns |
| Assume context is fresh | Verify file contents before editing |
| Loose tool descriptions | Use prompt-engineered tool metadata |

## Guidelines

*   **Fail fast:** Detect errors early.
*   **Checkpoint often:** Update `STATE.md` every major turn.
*   **Log reasoning:** Always explain "Thought" before "Action".

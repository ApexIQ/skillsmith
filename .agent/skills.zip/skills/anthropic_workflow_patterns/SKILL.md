---
name: anthropic_workflow_patterns
description: Implementation of Anthropic's five reliable agentic workflow patterns.
version: 1.0.0
tags: [anthropic, agentic, workflow, reliable-agent, orchestration]
---

# Anthropic Workflow Patterns

Use these patterns to build reliable agentic systems. Focus on simple, composable paths rather than complex dynamic loops where possible.

## 1. Prompt Chaining
Break a large task into a fixed sequence of LLM calls.
- **Use when:** Task is clearly decomposable into linear steps.
- **Benefit:** Each step is simpler, improving overall accuracy and reducing latency per call.

## 2. Routing
Use a "Router" LLM to classify intent and direct the request to a specialized expert model or sub-workflow.
- **Use when:** Diverse inputs require different specialized processing.
- **Benefit:** Allows expert models to focus on narrow domains.

## 3. Parallelization
Run independent subtasks simultaneously.
- **Sectioning:** Break task into independent pieces.
- **Voting:** Run same task N times and pick best output.
- **Use when:** Speed is critical or task has independent components.

## 4. Orchestrator-Worker
An orchestrator LLM dynamically breaks a complex task into subtasks and assigns them to worker LLMs.
- **Use when:** Task complexity is dynamic and hard to predict upfront.
- **Benefit:** Highly flexible; workers can run in parallel or sequence.

## 5. Evaluator-Optimizer
A two-stage loop where a Generator produces an output and an Evaluator provides feedback for self-correction.
- **Iteration:** Loop until Evaluator approves or max retries reached.
- **Use when:** Quality is paramount (e.g., code generation, reasoning).
- **Benefit:** Mathematically proven to reduce error rates in production.

## Implementation Guidelines
- Prioritize **Workflow** (fixed paths) over **Agents** (dynamic loops).
- Maintain transparency by logging the internal reasoning "thought" process.
- Use **Model Context Protocol (MCP)** for seamless tool integration.

---
name: ffuf_claude_skill
description: Web fuzzing with ffuf
source: https://github.com/jthack/ffuf_claude_skill
risk: safe
version: 0.1.0
---

# Ffuf Claude Skill

## Overview

Web fuzzing with ffuf

## When to Use This Skill

Use this skill when you need to work with web fuzzing with ffuf.

## Instructions

This skill provides guidance and patterns for web fuzzing with ffuf.

For more information, see the [source repository](https://github.com/jthack/ffuf_claude_skill).

---
name: agentic_context_engineering
description: Advanced strategies for maintaining state and optimizing context in long-running agentic sessions.
version: 1.0.0
tags: [context, engineering, memory, optimization, state-management]
---

# Agentic Context Engineering

Mastering the context window is the differentiator between a "toy" agent and a production-grade AI system.

## 1. "Just-in-Time" Context
Don't load everything at once. Use lightweight identifiers and load full content only when the agent decides to "view" or "read" it.
- **Pattern:** `Search -> Identify Path -> Read Content`.

## 2. Progressive Disclosure
Structure your context so the most important information (PRD, STATE.md, Core API) is always available, while implementation details are loaded on-demand.

## 3. Context Compaction
Periodically summarize history to prevent context overflow.
- **Snapshotting:** Save the current state of a task into `STATE.md`.
- **Archiving:** Move completed task details to a log file.

## 4. Universal State Protocol (Search-then-GSD)
Follow the Skillsmith **Search-then-GSD** protocol for state persistence:
- **SEARCH**: Always find and read relevant skills first.
- **`PROJECT.md`**: Immutable vision and tech stack.
- **`ROADMAP.md`**: Strategic milestones.
- **`STATE.md`**: Current task status and next steps (Read FIRST every session).

## 5. Metadata Tagging
Use standard identifiers like `id: XXX` in checklists to allow agents to track atomic progress across multiple turns without re-reading the whole file.

## Verification
- Run `skillsmith budget` to measure your current context load.
- Ensure `STATE.md` is updated every 5-10 tool calls to prevent context drift.
